**To describe an Elastic GPU**

Command::

  aws ec2 describe-elastic-gpus --elastic-gpu-ids egpu-12345678901234567890abcdefghijkl